package com.telefonica.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringGTcarsApplicationTests {

	@Test
	void contextLoads() {
	}

}
